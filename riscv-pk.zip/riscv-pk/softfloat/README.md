# Berkeley SoftFloat

- http://www.jhauser.us/arithmetic/SoftFloat.html

## Release 3e

Release 3 was a complete rewrite of SoftFloat, funded
by the University of California, Berkeley.

- http://www.jhauser.us/arithmetic/SoftFloat-3e.zip
